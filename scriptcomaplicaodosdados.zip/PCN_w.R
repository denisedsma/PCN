# PCN functions

library(dplyr)

# mirror a matrix function
espelha<-function(x){
  X1=X2=X3<-x
  n<-dim(x)[1]
  for ( i in 1:n){
    for ( j in 1:n){
      X1[i,j]<-x[(n-i+1),(n-j+1)]
      X2[i,j]<-x[(n-i+1),j]
      X3[i,j]<-x[i,(n-j+1)]
    }
  }
  m1.1<-cbind(X1,X2,X1)
  m1.2<-cbind(X3,x,X3)
  m1.3<-cbind(X1,X2,X1)
  m2<-rbind(m1.1,m1.2,m1.3)
  m2
}

# Calculates the observed value of the neighborhood of order o to site ij
# mm - matrix
# i - line
# j - column
# o - order
# a - alphabet
# n - size of matriz n x n
# border - if matrix contains border or not (DEFAULT is FALSE)
# adapted to deal with water pixels even when a = 2
ordem <- function(mm, i, j, o, a, n, border = FALSE){
  if (border == FALSE)   m2<-espelha(mm)
  else m2 <-mm
  l1<-m2[(n+i-o),(n+j-o):(n+j+o-1)]
  l2<-m2[(n+i+o),(n+j-o+1):(n+j+o)]
  l3<-m2[(n+i-o+1):(n+i+o),(n+j-o)]
  l4<-m2[(n+i-o):(n+i+o-1),(n+j+o)]
  tbl<-table(c(l1,l2,l3,l4,1:a))
  obs<-matrix(tbl)[,1]-1
  if(0 %in% names(tbl)) obs <- obs[1] + 1 + obs[a]
  else obs<- obs[-a]
  obs
}


# Update number of sites and neighborhood found within the matrix
obs.ordem<-function(m, dados, achou, obs, o, i, j, a, n, border = FALSE){
  # If the context already exists
  if( length(achou)==1){
    dados[[o]][achou,(o*(a-1)+a)]<-dados[[o]][achou,(o*(a-1)+a)] + 1
    if(border == FALSE){
      if(m[i,j]<a)dados[[o]][achou,(o*(a-1)+m[i,j])]<-dados[[o]][achou,(o*(a-1)+m[i,j])]+1
    } else{
      if(m[(i+n),(j+n)]<a)dados[[o]][achou,(o*(a-1)+m[(i+n),(j+n)])]<-dados[[o]][achou,(o*(a-1)+m[(i+n),(j+n)])]+1
    }
  }
  # If the context does not exist
  if(length(achou)==0){
    dados[[o]]<-rbind(dados[[o]], c(obs[1:(o*(a-1))],rep(0,(a-1)),1))
    if(border == FALSE){
      if(m[i,j]<a)dados[[o]][dim(dados[[o]])[1],(o*(a-1)+m[i,j])]<-1
    } else{
      if(m[(i+n),(j+n)]<a)dados[[o]][dim(dados[[o]])[1],(o*(a-1)+m[(i+n),(j+n)])]<-1
    }
  }
  dados
}


#Create sample tree from a given matrix
#adapted for water pixels even when a = 2
arv.amostral<-function(m, n, a, border = FALSE){
  
  dados<-NULL
  ## log(n/2) elements = max order of a neighborhood
  dados<-vector("list", (trunc(log(n/2))))
  obs<-NULL
  # To find context:
  # Calculate for site i=j=1 all neighborhood values
  for ( o in 1: trunc(log(n/2))) {
    obs<-c(obs, ordem(m, 1, 1, o, a, n, border))
    dados[[o]]<-rbind(dados[[o]], c(obs[1:(o*(a-1))],rep(0,a)))
  }
  #Do the same for all other sites
  for(i in 1:n){
    for ( j in 1: n){
      obs<-NULL
      # If matrix does not have border
      if(border == FALSE){
        #If the evaluated pixel is water, skip to the next
        if(m[i,j]!= 0){
          #Calculate the neighborhood value for each order
          for ( o in 1: trunc(log(n/2))){
            obs<-c(obs, ordem(m, i, j, o, a, n, border))
            achou<-1: dim(dados[[o]])[1]
            for( p in 1:(o*(a-1))) achou<-achou[which(dados[[o]][achou,p]==obs[p])]
            #Update with new neighborhood or existing one
            dados<-obs.ordem(m, dados, achou, obs, o, i, j, a, n, border)
          }
          obs
          achou
        }
      } else {  #If border is present
        ##If the evaluated pixel is water, skip to the next
        if(m[(i+n),(j+n)]!= 0){
          #Calculate the value of the neighborhood 
          for ( o in 1: trunc(log(n/2))){
            obs<-c(obs, ordem(m, i, j, o, a, n, border))
            achou<-1: dim(dados[[o]])[1]
            for( p in 1:(o*(a-1))) achou<-achou[which(dados[[o]][achou,p]==obs[p])]
            #Update with new neighborhood or existing one
            dados<-obs.ordem(m, dados, achou, obs, o, i, j, a, n, border)
          }
          obs
          achou
        }
      }
    }
  }
  #Remove from final tree if total sites observed are 0!
  if(border == FALSE && m[1,1]==0){
    for (ordem in trunc(log(n/2)):1){
      if(dados[[ordem]][1,(ordem+2)]==0){
        dados[[ordem]]<- dados[[ordem]][-1,]
      }
    }
  }
  if(border == TRUE && m[(n+1),(n+1)]==0){
    for (ordem in trunc(log(n/2)):1){
      if(dados[[ordem]][1,(ordem+2)]==0){
        dados[[ordem]]<- dados[[ordem]][-1,]
      }
    }
  }
  dados
}


#Calculate Pdj
pdj<-function(dados,o,s,n){
  A = 2 #alphabet
  aprod<-0
  
  ns<-dados[[o]][s,(o+2)]
  nsa<- c(dados[[o]][s,(o+1)], dados[[o]][s,(o+2)]-dados[[o]][s,(o+1)])
  
  if (any(nsa == 0)){
    for (a in 1:A) {
      aprod<- aprod + log((nsa[a]/ns)^nsa[a])
    }
  }else {
    for (a in 1:A) {
      aprod<- aprod + nsa[a]*log(nsa[a]/ns)
    }
  }
  aprod<- aprod - log(n^((A-1)/2))
}


#Calculate indicator function 
Vdj<-function(dados, n){
  # Calculate  Vs and Xs
  for ( o in 1: length(dados)) dados[[o]]<-cbind(dados[[o]],0,0)
  # Start with the last nodes of the tree 
  u<-length(dados)
  nfilhos<-dim(dados[[u]])[1]
  for( f in 1:nfilhos) dados[[u]][f,(o+3):(o+4) ]<-c(pdj(dados,u,f,n),0)
  # Do for the rest (going up the tree)
  for( o in (u-1):1){
    nstring<-dim(dados[[o]])[1]
    for( s in 1:nstring){
      #s=1
      # Children of s
      filhos<-1: dim(dados[[(o+1)]])[1]
      for (p in 1: o) filhos<- filhos[which(dados[[(o+1)]][filhos,p]==dados[[o]][s,p])]
      #Product of the children
      vprod<-sum(dados[[(o+1)]][filhos,(o+4)])
      # See if product of the children is greater than pdj of the parent node
      dados[[o]][s,(o+3):(o+4)]<-c(max(pdj(dados,o,s,n),vprod),sum(vprod > pdj(dados,o,s,n))) 
    }
  }
  dados
}

#Trim sample tree
poda<-function(arv.dados,a){
  # For all orders
  for ( o in 1:(length(arv.dados)-1)){
    i=1   
    if( is.vector(arv.dados[[o]]))arv.dados[[o]]<-matrix(arv.dados[[o]],nrow=1)
    if(dim(arv.dados[[o]])[1]==0)i<-dim(arv.dados[[o]])[1]+1 
    # Evaluate all neighborhoods
    while (i<=dim(arv.dados[[o]])[1]){
      aux<-NULL
      if( is.vector(arv.dados[[o+1]]))arv.dados[[o+1]]<-matrix(arv.dados[[o+1]],nrow=1)
      #Look at the indicatior X represented by column =  o(a-1)+(a-1)+ntotal+V+X
      if (arv.dados[[o]][i,(a*o- o +a +2)]==0 && dim(arv.dados[[(o+1)]])[1]>0){
        corte<-arv.dados[[o]][i,1:(o*(a-1))]
        for(oo in (o+1):(length(arv.dados))){
          if( is.vector(arv.dados[[oo]]) )arv.dados[[oo]]<-matrix(arv.dados[[oo]],nrow=1)
          aux<-matrix(rep(corte,dim(arv.dados[[oo]])[1]),ncol=length(corte),byrow=T)
          aux2<-matrix(arv.dados[[oo]][,1:o],ncol=o)
          corte2<-which(rowSums(aux2-aux)==0)
          arv.dados[[oo]]<-arv.dados[[oo]][-corte2,]
        }
      }
      if (arv.dados[[o]][i,(a*o- o +a +2)]==1){
        arv.dados[[o]]<-arv.dados[[o]][-i,]
        i<-i-1
        if( is.vector(arv.dados[[o]]))arv.dados[[o]]<-matrix(arv.dados[[o]],nrow=1)
      }
      i<-i+1
    }
  }
  arv.dados
}
