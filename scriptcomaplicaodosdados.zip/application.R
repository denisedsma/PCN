# Script for getting a matrix within Pantanal
# and evaluating the dependence tree

# Load libraries
library(rgdal)
library(ggplot2)
library(stars)
library(raster)

# Get Pantanal boundaries
pantshp <- readOGR("biome_border.shp")
pantshp

#Find some more info about it
head(pantshp)
class(pantshp)
dim(pantshp)
names(pantshp)

#Plot
pp<-fortify(pantshp) 
dim(pp)
class(pp)
ggplot(data = pp, aes(x=long, y=lat, group = group)) + geom_path() 

#Find the 4 coordinate points to assist the choice of the square sample
coords<-pantshp@polygons[[1]]@Polygons[[1]]@coords
dim(coords)
class(coords)
#west point
west<-pp[which(-19< pp$lat & pp$lat< -17 & pp$long < -57),]
W <- as.numeric(west[which(west$long==max(west$long)),][,1:2]) #-57.45392 -18.23119
#east point
east<-pp[which(-19< pp$lat & pp$lat< -17 & pp$long > -56),]
E <- as.numeric(east[which(east$long==min(east$long)),][,1:2]) #-55.21658 -18.25496
#southeast point
southeast<-pp[which(-19> pp$lat & pp$lat> -20 & pp$long > -56),]
SE <- as.numeric(southeast[which(southeast$long==min(southeast$long)),][,1:2]) #-55.5552 -19.89007
#south point
south<-pp[which(-19> pp$lat & pp$lat> -20 & pp$long < -56 & pp$long > W[1]),]
S <- as.numeric(south[which(south$lat==max(south$lat)),][,1:2]) #-57.13415 -19.77219
#north point
north<-pp[which(-17< pp$lat & pp$long< SE[1] & pp$long > W[1]),]
N <- as.numeric(north[which(north$lat==min(north$lat)),][,1:2]) #-56.81776 -16.27928

#plot limiting points in pantanal 
ggplot(data = pp, aes(x=long, y=lat, group = group)) + geom_path() +
  geom_point(aes(x=W[1], y=W[2]), size=2, color="orange") +
  geom_point(aes(x=E[1], y=E[2]), size=2, color="green") +
  geom_point(aes(x=SE[1], y=SE[2]), size=2, color="blue") +
  geom_point(aes(x=S[1], y=S[2]), size=2, color="red") +
  geom_point(aes(x=N[1], y=N[2]), size=2, color="purple") 

#maximum height of the box
N[2]-S[2]
#maximum width of the box
W[1]-SE[1]
W[1]-E[1]

# Create sample matrix 
#WINDOW 6 - MODIS
w2 <- read_stars("MCD64monthly.A2020245.Win06.006.burndate.tif")
w2

st_coordinates(w2)
#window 06:
ymax = -10.0022
ymin = -34.99829
xmin = -78.9978
xmax = -34.0020
delta = 0.00439453
#10,240 x's and 5,684 y's 

# pantanal coordinates 
coord<-st_coordinates(w2)
#long min
pxmin = coord[which((coord[1]-W[1])>0),][1,1]
#-57.45142 ,column 4904
#long max
pxmax = coord[which((coord[1]-E[1])>0),][1,1]
#-55.2146, column 5413
#lat max 
#pymax = coord[which((coord[2] - -17.08351)<0),][1,2]
pymax = -17.08179 #linha 1611
#-17.08618, line 1612 (16506881/10240)
#lat min
coord[which((coord[2]- -19.32084)<0),][1,]
pymin = coord[(21719041-10240),][,2]
#-19.3186, line 2120 (21708801/10240)
length(1611:2120) 
length(5413:4904) 
#since this region generates a 510 x 509 matrix, 
#we took pymax = -17.08179, line 1611 (16496641/10240) to have a 510x510 matrix.

#plot sample area 510 x 510
ggplot(data = pp, aes(x=long, y=lat)) +
  geom_path(color = "green4", size = 1.2) +
  geom_rect(aes(xmin = pxmin, ymin = pymin,
                xmax= pxmax, ymax = pymax), color = "tan4", size = 1.2, alpha = 0)

#Select 3m x 3m matrix (matrix with border)
#save matrix in an object
matriz06 <- t(w2[[1]]) 
dim(matriz06) #5,689 x 10,240

rotate <- function(x) apply(x, 2, rev)
image(t(rotate(matriz06)), useRaster = TRUE)

dim(matriz06[1611:2120,4904:5413]) #510x510
n=510
pantanal2 <- matriz06[(1611-n):(2120+n),(4904-n):(5413+n)]
dim(pantanal2)

#plot pantanal
image(1:dim(pantanal2)[1],1:dim(pantanal2)[1], t(rotate(pantanal2)), 
      useRaster = TRUE, zlim = c(0,274), xlab = "", ylab = "")
image(1:n,1:n, t(rotate(pantanal2[(n+1):(2*n),(n+1):(2*n)])), 
      useRaster = TRUE, zlim = c(0,274), xlab = "", ylab = "")

#Create pantanal matrix with water 
pantanal2_w<-pantanal2
table(pantanal2_w)
pantanal2_w[pantanal2_w == 0] <- 1 #land = not fire
pantanal2_w[pantanal2_w == -2] <- 0 #water = won't be analysed
pantanal2_w[pantanal2_w>=245 & pantanal2_w<=274] <- 2 #fire by date = fire
table(pantanal2_w)

#Plot 
pant2_w<-pantanal2_w[(n+1):(2*n),(n+1):(2*n)]
dim(pant2_w)

image(1:n, 1:n, t(rotate(pant2_w)),
      col = hcl.colors(n = 3, "Berlin", alpha = 1, rev = FALSE),
      xlab ="", ylab="", useRaster = TRUE)
#with border
bpant2_w<-pantanal2_w[(n+1-5):(2*n+5),(n+1-5):(2*n+5)] 
dim(bpant2_w)

image(1:dim(bpant2_w)[2], 1: dim(bpant2_w)[1], z = t(rotate(bpant2_w)),
      col = c("royalblue4", "green4","firebrick4"),
      xlab = "", ylab = "", useRaster = TRUE)
#add boxfor the sample separating from border
b<- c(6, 515)
segments(x0 = b[1], y0 = b[1], x1 = b[2], y1 = b[1], col = "ivory") #linha horizontal inferior
segments(x0 = b[1], y0 = b[2], x1 = b[2], y1 = b[2], col = "ivory") #linha horizontal superior
segments(x0 = b[1], y0 = b[1], x1 = b[1], y1 = b[2], col = "ivory") #linha vertical a esquerda
segments(x0 = b[2], y0 = b[1], x1 = b[2], y1 = b[2], col = "ivory") #linha vertical a direita

#how many pixels for each category
nrow(which(pantanal2_w == 0, arr.ind = TRUE)) #15,956 water
nrow(which(pantanal2_w == 1, arr.ind = TRUE)) #2,222,809 not fire
nrow(which(pantanal2_w == 2, arr.ind = TRUE)) #102,135 fire

nrow(which(pant2_w == 0, arr.ind = TRUE)) #7,881 water
nrow(which(pant2_w == 1, arr.ind = TRUE)) #230,114 not fire
nrow(which(pant2_w == 2, arr.ind = TRUE)) #22,105 fire

# RUN ALGORITHM 
#run functions adapted to matrices of 0,1 and 2.
source("PCN_w.R")

#Create sample tree with all the neighborhoods of the sample
n=510
start_time <- Sys.time()
arv_pantanal2_w<- arv.amostral(pantanal2_w, n, 2, border = TRUE) 
end_time <- Sys.time()
end_time - start_time

#Add indicator variable
indica2_w<- Vdj(arv_pantanal2_w, n)

#Prune tree based on indicator variable
poda_pantanal2_w<- poda(indica2_w, a=2)
poda_pantanal2_w

#Results: First order dependence for all neighborhoods, 
#except for frame with 8 (not fires) around, then it's necessary
#to go to the second order to the determine conditional probability.

#Calculate sample's conditional probability of pixel not being fire
p2_est1_w<-poda_pantanal2_w[[1]][,2]/poda_pantanal2_w[[1]][,3] 
arv2_est1_w <- cbind(poda_pantanal2_w[[1]],p2_est1_w)
arv2_est1_w
p2_est2_w<-poda_pantanal2_w[[2]][,3]/poda_pantanal2_w[[2]][,4] 
arv2_est2_w <- cbind(poda_pantanal2_w[[2]],p2_est2_w)
arv2_est2_w
